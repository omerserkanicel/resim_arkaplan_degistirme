import cv2

# Resmi aç
image = cv2.imread("sonuc.jpeg")

# Metni ve başlangıç koordinatlarını tanımla
text = "Okula giderken Annem cantani aldinmi demistir"

x, y = 10, 130  # X ve Y koordinatları (başlangıç noktası)
# Metni resme ekleyin
font = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 2.5  # Metin ölçeği
font_color = (74, 128, 77)  # Metin rengi (BGR formatında)
font_thickness = 10  # Metin kalınlığı

cv2.putText(image, text, (x, y), font, font_scale, font_color, font_thickness)



# Metni yeni koordinatlara taşıyın

# Resmi kaydet
cv2.imwrite("resim.jpg", image)
