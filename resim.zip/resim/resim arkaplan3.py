from PIL import Image

img = Image.open("C:/Users/MONSTER/Desktop/resim/sonuc.jpeg")  # Resmin dosya yolunu belirtin
from PIL import ImageDraw, ImageFont

draw = ImageDraw.Draw(img)

text = "Merhaba, Dünya!"
font = ImageFont.truetype("arial.ttf", size=100)  # Kullanmak istediğiniz font ve boyutu belirtin

draw.text((500, 10), text, fill="white", font=font)  # Metni resme ekleyin

img.save("yeni_resim.jpg")  # Değişiklikleri kaydetmek için resmin yeni bir kopyasını kaydedin
