from PIL import Image

# Arka planÄ± deÄŸiÅŸtireceÄŸiniz resim
foreground = Image.open('output.png')

# Yeni arkaplan
background = Image.open('zyro.png')

# Resimleri boyutlandÄ±rma (eÄŸer gerekirse)
background = background.resize(foreground.size)


# Yeni arkaplanÄ± ekleyin
background.paste(foreground, (0, 0), foreground)

# Sonucu kaydetme
background.save('sonuc1.png')

